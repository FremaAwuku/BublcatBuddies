// function sum(array){
//     totalSum = 0;
//
//     for (let i = 0 ; i < array.length; i++){
//
//         totalSum += array[i]
//     }
//     return totalSum
// }
// let arr = [1,2,3]
// sum(arr)
