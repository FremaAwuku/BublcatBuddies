/**
 * 1. Prompt a for max and min number to set range
 *      > accept param of max and min
 * return string with max and min
 *      "I'm thinking of..""
 *
 * setTimeout ?
 *
 * prompt for guess
 * if (guess > max) return too high
 * if
 *
 */
