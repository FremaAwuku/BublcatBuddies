/***********************************************************************
Write a recursive function reverse(string) that takes in a string and returns
it reversed.

/* Base case - if string.length === 0 return string[0]
   return whatever the string is- string + reverse(string.slice(1))
***********************************************************************/
function reverse(string){
  debugger;
  if(string.length === 0){
    debugger;
    return "";
  }
  debugger;
  let stringSlice = reverse(string.slice(0, string.length -1))
  debugger;
  return string[string.length -1] + stringSlice
  debugger;
}




console.log(reverse("house")); // "esuoh"
console.log(reverse("dog")); // "god"
console.log(reverse("atom")); // "mota"
console.log(reverse("q")); // "q"
console.log(reverse("id")); // "di"
console.log(reverse("")); // ""

/**************DO NOT MODIFY ANYTHING UNDER THIS LINE*****************/
try {
  module.exports = reverse;
} catch (e) {
  module.exports = null;
}
