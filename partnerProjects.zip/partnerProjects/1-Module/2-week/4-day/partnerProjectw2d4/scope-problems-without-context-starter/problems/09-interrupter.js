/***********************************************************************
Write a function named: interrupter(interruptingWord). The interrupter function will
accept a word and return a function. When the function returned by interrupter
is invoked with a string the string will be returned with "interruptions".

Look below to see how this function is invoked:

//return a func
//action func >> insert interruptin word in between every othe word
//str > arr .split

//for loop (array.length -1)

//iterate with .map
//.Pop

***********************************************************************/

// your code here!
let interrupter = interruptingWord => str => str.split(' ').join(' ' + interruptingWord + ' ');
const interrupter = (interupptingWord) =>{


return interupt = (str) =>{

  return str.split(" ").join(" " + interupptingWord + " ")
}
}
// let popArr = str.split(" ");
// let result = [];

// for (let i = 0; i < popArr.length; i++) {
//   const word = popArr[i];
//   result.push(word)
//   result.push(interupptingWord)

// }
// result.pop()
// return result.join(' ')

// }

// let arr = str.split(' ')


    //  let result = newStr.map(word => {
    //   return word + " " + interupptingWord
    //  })
    // //  result.pop()

    // for (let i = 0 ; i< arr.length-1; i++){
    //   arr[i] +=  " " + interupptingWord

    // }
    //  return arr.join(' ')


let rudePerson = interrupter("what"); // => returns a function
console.log(rudePerson("how are you")); // prints "how what are what you"
console.log(rudePerson("I like pie")); // prints "I what like what pie"



let rudePerson2 = interrupter("yo"); // => returns a function
console.log(rudePerson2("I love dogs")); // prints "I yo love yo dogs"

/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/

try {
  module.exports = interrupter;
} catch (e) {
  // catch the ref err
  module.exports = null;
}
