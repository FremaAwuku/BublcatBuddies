/***********************************************************************
Write a function named `smoothieMachine` that accepts any number of params and
a function.

The return function will also accept any number of params and will return a
string including all of the parameters of smoothieMachine and the return
function.

1. rest paramter must be used in outer func
2. rest parameter to be used on inner func
3. both return a function

1. create a containing variable as string
  why?  will hold changes made during each passing
2. create inner func
  >> it will do the job of manipulatiing str


smoothie 1 is only pushing arguements to INNER FUNC

smoothieMachine deals with arguements found in its specific invocation
will be decalered as paramet in OUTTER FUNC

"and" string must be added in between each passing and added to arguements
use .Join method


See below for examples:


***********************************************************************/

const smoothieMachine = (...food) =>{

  return blender = (...ing) =>{
    food = food.concat( ing)
    // console.log(food)
//REASSIGN OUTER PARAMETER TO THE ADDITION OF INCOMING PARAMETS
//CONATINIG VARIABLE
//MUST USE CONCAT!!!!
      //why? IT allows us to ADD INCOMIMG ARGS TO ARRAYS
      //>>there is an understanding that rest params turn incoming arguments into ARRAYS
      //Using this method
      // food = food + ing<<< results in arrays turning into strings that areadded together



//WHY??? COULDNT I REASSIGN THE 2nD PARAMETER(ing) that accepts args from VARARIABLE FUNC(smoothie1&2)
    // ing = ing.concat(food)
    // console.log(ing)
//PRIVATE STATE
  //EXAMPLE 1
    // these ...ing parameters>>>that are actually now an array of arguements>>> isnt just given during ONE INVOCATION
    //these parameters are invoked (1) in a VARIABLE smoothie1 (2) 3 times
    //so the ing parameter changes each time the smoothie1 variable is invoked
    //the ing parameter(variable) is DYNAMIC and we need a varible that will stay STATIC
    //we can rely on the OUTER PARAM to do the job of containging because withing the variable (smoothie1)
    //smoothieFunc and its arguements have the ability to do allow the inner functio to work multiple times
    //and allow OUTER variables to contain the changes made THROUGH EACH INVOCATION

  //EXAMPLE 2
  //ing was the variable (accepting arguements fron VARIABLE FUNCs(smoothie2) that create PS)
  //being changed over invocations however because there was only one invocation of smoothie2 AND THEN smoothieMaker
  // we ended up witha  print of one array looking like this [ 'pineapple', 'apples', 'bananas', 'berries' ]
/*
    When the DESIRED effect was [ 'apples', 'bananas', 'berries', 'pineapple' ]
        //why||how is Pineapple at the END here?
        //WHEN the correct variable of food is reassigned to chaining of arguements through the concat
         method  adds incoming arugements of INNER FUNC (ing)>>>pineapple

*/

// we finally return the problem with the string that will print whole orer
    //my understanding broken down
//1)we return with the string "I'm having..." because that is actaully staying STATIC througout the returns of the FUNC
//2)we REASSIGN the FIRST ARRAY/PARAM OF INCOMING ARGUEMNTS(food) to ADD (.concat()) INCOMING ARGUEMENTS IN THE ARRAY OF THE 2nd FUNC
    //THROUGH EACH INVOCATION OF VARIABLE FUNC THAT CREATES PRIVATE STATE
//3) we add (+ || .concat() because the final result is a string) our CONTAING ARUGEMENT ARRAY and .JOIN("and") on the str AND

//3a) *** .join() will allow "and" to be IN BETWEEN incoming arguements allowing them to print without extra ands 
return "I'm having a smoothie with ".concat( ing.join(" and "))
}
}
let smoothie1 = smoothieMachine();

console.log(smoothie1("milk"));
// prints "I'm having a smoothie with milk"
console.log(smoothie1("kale", "spinach"));
// prints "I'm having a smoothie with milk and kale and spinach"
console.log(smoothie1("honey", "pears", "berries"));
// prints "I'm having a smoothie with milk and kale and spinach and honey and pears and berries"

let smoothie2 = smoothieMachine("apples", "bananas", "berries");
console.log(smoothie2("pineapple"));
// prints "I'm having a smoothie with apples and bananas and berries and pineapple"
/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/
try {
  module.exports = smoothieMachine;
} catch (e) {
  // catch the ref err
  module.exports = null;
}
