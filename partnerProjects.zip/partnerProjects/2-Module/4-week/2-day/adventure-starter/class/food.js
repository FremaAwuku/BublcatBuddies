
// FILL THIS OUT

class Food {

}

module.exports = {
  Food,
};
