1. mocha logic of being able to move cursor

   > To process keypresses, you will need to load `Command` objects into the Screen
    API using `Screen.addCommand`.
        >This function takes a `key` which triggers the
command,
        >a string `description`,
        >and an `action` callback which is executed
        when `key` is pressed

HOW? LOOP? ARRAY?
>>The game should alternate turns between `O` and `X` until one player wins or
the game ends in a tie.<<
