const Screen = require("./screen");

class Cursor {

  constructor(numRows, numCols) {


    this.numRows = numRows;
    this.numCols = numCols;

    this.row = 0;
    this.col = 0;

    this.gridColor = 'black';
    this.cursorColor = 'yellow';
    Screen.render();
  }

  resetBackgroundColor() {
    Screen.setBackgroundColor(this.row, this.col, this.gridColor);
  }

  setBackgroundColor() {
    Screen.setBackgroundColor(this.row, this.col, this.cursorColor);
    Screen.render();
  }



  down() {
   //reset color
   this.resetBackgroundColor()//thats it
  //  //move Cursor up
  //  if(this.row >= this.numRows -1 ){//keeps us within the grid


  //  }else if (this.row < this.numRows){

    this.row = this.row + 1
    if (this.row >= this.numRows ) this.row = this.numRows - 1;

  //  }
   //new background color
   this.setBackgroundColor()//to yellow
  //  //render it on the Screen
  //  Screen.render()


  }
  up() {
    //reset color
    this.resetBackgroundColor()//thats it
    //move Cursor up
    this.row = this.row -1
    if(this.row < 0) this.row = 0
    // if(this.row < this.numRows ){//keeps us within the grid
    //   this.row -= 1
    // }else if(this.row < 0){
    //   this.row = 0
    // }else{
    //   return
    // }
    //new background color
    this.setBackgroundColor()//to yellow
    //render it on the Screen


  }

  left() {
    // this.resetBackgroundColor()
    // if(this.col >  this.numRows){
this.col = this.col -1
if(this.col < 0){ this.col = 0

}

    // }
    // this.setBackgroundColor()

    // Screen.render()
  }

  right() {
    this.col = this.col + 1
    if (this.col >= this.numCols) this.col = 0 ;
  }

}


module.exports = Cursor;
