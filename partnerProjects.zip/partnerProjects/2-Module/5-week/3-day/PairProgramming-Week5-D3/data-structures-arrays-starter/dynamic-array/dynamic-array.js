class DynamicArray {

  constructor(size=4) {
    this.capacity= size;
    this.length = 0;
    this.data = new Array(size);
  }

  read(index) {
    return this.data[index];
  }

  push(val) {
    if (this.length === this.capacity) {
      //this.capacity *= 2;
      this.resize();
    }
    this.data[this.length] = val;
    this.length++;
  }


  pop() {
    let last = this.data[this.length - 1];
    this.length--;
    return last;
  }
//loop forward starting at index 1
//rewrite each value as i -1
//this length --


  shift() {
    let first = this.data[0]
    for ( let i = 1; i < this.length; i++){
        let value = this.data[i];
        this.data[i - 1] = value;
    }
    this.length --;
    return first
  }



  unshift(val) {
    // add to length of array, this.data
    // loop backwards, each index + 1
    // if first index (i = 0) then index = val
    if (this.length === this.capacity) {
      //this.capacity *= 2;
      this.resize()
    }

    this.length++;

    for (let i = this.length - 1; i >= 0; i--) {

      let index = this.data[i];

      if (index !== undefined) {
        this.data[i + 1] = index;
      }

      if (i === 0) {
        this.data[i] = val;
      }
    }
  }
  // for loop
    // if data[i] == val return i
    //else return - 1
  indexOf (val) {

    for(let i = 0 ; i < this.length ; i++){
      if (this.data[i]=== val){
        return i
      }}
      return -1
  }

  resize () {
    this.capacity *= 2;


    // from EOD
    let newData = new Array(this.capacity);

    for (let i = 0; i < this.length; i++) {
      newData[i] = this.data[i]
    }
    this.data = newData;
  }

}


module.exports = DynamicArray;
