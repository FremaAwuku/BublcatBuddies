# Binary and Logic practice

To warm up, you will be converting integers between different bases and from
`ASCII` and `binary`. Following this, test your logic skills by filling out
some truth tables. Keep track of your answers in comments to compare with the
solutions later.

When you feel like you've gotten the right answers, check with the solutions to
confirm. If you missed some, try to work through them again in your pairs.