class DynamicArray {

  constructor(size=4) {

    // Fill this out
    this.length = 0;
    this.capacity = size;
    this.data = Array(size);
  }

  push(val) {
    this.data[this.length] = val;
    this.length++;
  }

  read(index) {
    return this.data[index];
    // Fill this out
    // You may not use any built-in JS array functions
  }

  unshift(val) {

    // Fill this out
    // You may not use any built-in JS array functions

  }

}


module.exports = DynamicArray;



