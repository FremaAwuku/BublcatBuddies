
RESPONSIVE GUIDELINES
@media query
    nav bad min/max width = 959px/960px
