// Imports 
import * as manipulation from "./manipulate.js"
import * as search from "./search.js"


manipulation.changeTitle();
manipulation.changeHeader();
manipulation.changeAboutMe();
console.log(search.findElementById("header"));
console.log(search.findFirstElementOfTag("LI"));
console.log(search.findFirstElementOfClass("section"));
console.log(search.findElementsOfTag("H3"));
console.log(search.findElementsOfClass("section"));
