export function findElementById(id) {
    // Return the element in the DOM with corresponding `id`
    // return document.getElementById(id)
    let body = document.body
    let result = undefined
    function getChildId(ele){
        if(ele.id === id){
            result = ele;
            return;
        }
        for (let i = 0; i < ele.children.length; i++) {
            getChildId(ele.children[i])
        }
    }
    getChildId(body)
    return result;
}

export function findFirstElementOfTag(tag) {
    // Return the first occurence of an element of tag name `tag`
    // document.querySelector('tag')
    return document.getElementsByTagName(tag)[0]

}

export function findFirstElementOfClass(cls) {
    // Return the first occurence of an element of class `cls`
    return document.getElementsByClassName(cls)[0]
}

export function findElementsOfTag(tag) {
    // Return an array of elements that have a tag name of `tag`
    return document.getElementsByTagName(tag)

}

export function findElementsOfClass(cls) {
    // Return an array of elements that have are of class `cls`
    return document.getElementsByClassName(cls)
}
