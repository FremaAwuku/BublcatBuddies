export function changeTitle() {
    // Change the title of the page to "(Your name)'s Portfolio"
    window.document.title = 'Gina';
    
}

export function changeHeader() {
    // Change the name in the h1 of the page to your name
    let div = document.body.childNodes[1];
    let h1 = div.childNodes[1];
    h1.innerText = "Gina";
    
}

export function changeAboutMe() {
    /* Update the first paragraph in the About Me section with a small
     passage about yourself */
    let div = document.body.children[1];
    let p = div.children[1];
    console.log(div)
    p.innerText = "We learn to code!";
    
}
