/*
Write a function called `stretch`. It should:

- return a promise
- print `"done stretching"`
- fulfill the promise after 1 second
*/

// const promiseCB = (resolve, reject) => {
//   setTimeout(() => {
//     resolve()
//   }, 1000)
// };

// let thePromise = new Promise(promiseCB)
// .then(() => {
//   console.log('done stretching')
// })


// ^ not integrated into a function

function stretch() { // potentially then-in function
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      console.log('done stretching')
      resolve();
    }, 1000);
  })
}

// .then(() => { // for within the function above
//   console.log('after stretching')
// });

// function stretch() { // then out of function
//   return new Promise((resolve, reject) => {
//     setTimeout(() => {
//       console.log('done stretching')
//       resolve();
//     }, 1000);
//   })
// }

// stretch().then(() => { // for then out of function
//   console.log('after stretching')
// });


/*
Write a function called `runOnTreadmill`. It should:

- return a promise
- print `"done running on treadmill"`
- fulfill the promise after 0.5 seconds
*/

function runOnTreadmill() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      console.log("done running on treadmill")
      resolve();
    }, 500)
  });
}


/*
Write a function called `liftWeights`. It should:

- return a promise
- print `"done lifting weights"`
- fulfill the promise after 2 seconds
*/

function liftWeights() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      console.log('done lifting weights')
      resolve();
    }, 2000)
  });
}


/*
Write a function called `workout` that runs the above functions in a way
that ensures you begin running on the treadmill after you've finished
stretching. Begin lifting weights after running on the treadmill. Print
`"done working out"` after you've finished lifting weights.
*/

// function workout() {
//   stretch()
//   .then(runOnTreadmill)
//   .then(liftWeights)
//   .then(() => console.log("done working out"))
//   .catch((err) => console.log(err));
// }



/*
Test your code:

Run the file (`node part-1.js`) and check your output against the expected output.
*/


// workout();

// done stretching
// done running on treadmill
// done lifting weights
// done working out


// function allWorkouts() {
//   Promise.all([
//     stretch(), 
//     runOnTreadmill(), 
//     liftWeights()
//   ])

//   .then(() => console.log('done working out'))
//   .catch ((err) => console.log(err)); 
// }

// allWorkouts();




async function workout() {
  try {
  await stretch()
  await runOnTreadmill()
  await liftWeights()
  console.log('done working out')
  } catch (err) {
    console.log(err);
  }
}

workout()
