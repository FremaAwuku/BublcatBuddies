function stretch(timeLeft) {

}

function runOnTreadmill(timeLeft) {

}

function liftWeights(timeLeft) {

}

function workout(totalTime) {
	
}

// TESTS

// comment in each invocation of your workout function below and run
// the file (node part-2.js) to see if you get the expected output

// workout(1000);
// 		done stretching
// 		Error:  you dont have enough time to run on treadmill

// workout(2000);
// 		done stretching
// 		done running on treadmill
// 		Error:  you dont have enough time to lift weights

// workout(4000);
// 		done stretching
// 		done running on treadmill
// 		done lifting weights
// 		done workout out