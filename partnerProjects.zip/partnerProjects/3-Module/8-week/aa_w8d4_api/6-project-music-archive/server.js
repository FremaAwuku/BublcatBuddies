const http = require('http');
const fs = require('fs');

const artists = JSON.parse(fs.readFileSync('./seeds/artists.json'));
const albums = JSON.parse(fs.readFileSync('./seeds/albums.json'));
const songs = JSON.parse(fs.readFileSync('./seeds/songs.json'));

let nextArtistId = 2;
let nextAlbumId = 2;
let nextSongId = 2;
function getNewArtistId() {
  const newArtistId = nextArtistId;
  nextArtistId++;
  return newArtistId;
}
function getNewAlbumId() {
  const newAlbumId = nextAlbumId;
  nextAlbumId++;
  return newAlbumId;
}
function getNewSongId() {
  const newSongId = nextSongId;
  nextSongId++;
  return newSongId;
}

const server = http.createServer((req, res) => {
  console.log(`${req.method} ${req.url}`);

  let reqBody = "";
  req.on("data", (data) => {
    reqBody += data;
  });

  // When the request is finished processing the entire body
  req.on("end", () => {
    // Parsing the body of the request
    if (reqBody) {
      switch(req.headers['content-type']) {
        case "application/json":
          req.body = JSON.parse(reqBody);
          break;
        case "x-www-form-urlencoded":
          req.body = reqBody
            .split("&")
            .map((keyValuePair) => keyValuePair.split("="))
            .map(([key, value]) => [key, value.replace(/\+/g, " ")])
            .map(([key, value]) => [key, decodeURIComponent(value)])
            .reduce((acc, [key, value]) => {
              acc[key] = value;
              return acc;
            }, {});
          break;
        default:
          break;
      }
      console.log(req.body);
    }

    // GET /artists
    if (req.method === "GET" && req.url === "/artists") {
      const resBody = JSON.stringify(Object.values(artists));
      console.log(Object.values(artists),`<--js Obj`)
      res.statusCode = 200;
      res.setHeader('Content-Type', 'application/json');
      res.write(resBody);
      return res.end();
    }


    //Get a specific artist's details based on artistId
    if (req.method === "GET" && req.url.startsWith('/artists/')) {
      const urlParts = req.url.split('/');
      if (urlParts.length === 3){
        const artistID = urlParts[2];
        const resBody = JSON.stringify(artists[artistID])
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.write(resBody);
        return res.end();
      }

    }


    //# Add an artist
    if (req.method === "POST" && req.url === "/artists") {
      let artistId = getNewArtistId();
      const { name} = req.body
      const artist = {
        artistId: artistId,
        name
      };
      artists[artistId] = artist
      res.statusCode = 201;
      console.log(`New Artist Created`)
      res.setHeader('Content-Type', 'application/json');
      res.write(JSON.stringify(artist));
      return res.end();
    }


    //# Edit a specified artist by artistID
    if ((req.method === 'PUT' || req.method === 'PATCH')  && req.url.startsWith('/artists/')) {
      const urlParts = req.url.split('/');
      if (urlParts.length === 3) {
        const artistId = urlParts[2];
        let editedArtist;
        // const artist = artists.find(artist => artist.artistId == artistId);
        const { name } = req.body;
        for(let artistKey in artists){
          if(artistKey == artistId){
            editedArtist = artistKey

          }
        }
       artists[editedArtist].name = name ||
       artists[editedArtist].name;

        res.statusCode = 200;
        console.log(`Artist Updated`)
        res.setHeader('Content-Type', 'application/json');
        res.write(JSON.stringify(artists));
        return res.end();
      }
    }


    // # Delete a specified artist by artistId


  if (req.method === 'DELETE' && req.url.startsWith('/artists/')) {
    const urlParts = req.url.split('/');
    if (urlParts.length === 3) {
      const artistId = urlParts[2];

      const dogIdx = dogs.findIndex(dog => dog.dogId == dogId);
      dogs.splice(dogIdx, 1);

      res.statusCode = 200;
      res.setHeader('Content-Type', 'application/json');
      res.write(JSON.stringify({ message: "Successfully deleted" }));
      return res.end();
    }
  }




    // Route handlers here

    res.statusCode = 404;
    res.setHeader('Content-Type', 'application/json');
    res.write("Endpoint not found");
    return res.end();
  });
});

const port = 3000;

server.listen(port, () => console.log('Server is listening on port', port));
