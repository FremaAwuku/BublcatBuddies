# Get all the artists

*Request components:*
Method: GET
URL: /artists
Headers: none
Body: none

*Response components:*
Status Code: 200
Headers:
Content-Type: application/json
Body: information about all the artists(JSON)


# Get a specific artist's details based on artistId

*Request components:*
Method: GET
URL: /artists/:artistId
Headers:none
Body:none

*Response components:*
Status Code: 200
Headers:
Content-Type: application/json //.then(res => res.headers.get('Content-Type'))
Body: information about a specific artist(JSON)
fetch("/artists/1")
.then(async res =>{
console.log(res.status)
const body = await res.text()
console.log(body)
});


# Add an artist

*Request components:*
Method: POST
URL: /artists
Headers: Content-Type: application/json
Body: JSON with artist name and ID number

*Response components:*
Status Code: 200
Headers: Content-Type: application/json
Body:JSON string of new artist
//example of  body >>>{"name":"Dolly Parton","artistId":2}

fetch('/artists',{
  method: "POST",
  headers: {"Content-Type":"application/json"},
  body: JSON.stringify({
    name: "Lady Gaga"
  })
}).then(res => console.log(res.status));


# Edit a specified artist by artistID

*Request components:*
Method:PATCH/PUT
URL: /artists/:artistId
Headers: Content-Type: application/json
Body: JSON with updated artist info (to overwrite current info at that id)

*Response components:*
Status Code: 200
Headers: Content-Type: application/json
Content-Type: application/json
Body: JSON string of that artist with changes made
fetch('/artists/2',{
  method: "PATCH",
  headers: {"Content-Type":"application/json"},
  body: JSON.stringify({
    name: "Lady Gogo"
  })
}).then(res => console.log(res.status));

# Delete a specified artist by artistId
*Request components:*
Method: DELETE
URL: /artists/:artistId
Headers: Content-Type: application/json
Body: none

*Response components:*
Status Code: 200
Headers: Content-Type: application/json
Content-Type: application/json
Body: log "artist deleted"

fetch('/artists/1',{
  method: "DELETE",
}).then(res => console.log(res.status));



# Get all albums of a specific artist based on artistId
*Request components:*
Method: GET
URL: /artists/:artistId/albums
Headers: none
Body: none

*Response components:*
Status Code: 200
Headers: Content-Type: application/json
Body: json of albums list
  example: [{"name":"Stadium Arcadium","albumId":1,"artistId":1}]

fetch('/artists/:artistId/albums').then(async res =>{
console.log(res.status)
const body = await res.text()
console.log(body)
});
fetch('/artists/1/albums').then(res => res.json()).then(resBody => console.log(resBody));

})


# Get a specific album's details based on albumId
*Request components:*
Method: GET
URL: /albums/:albumId
Headers: none
Body: none

*Response components:*
Status Code: 200
Headers: Content-Type: application/json
Content-Type: application/json
Body: json of that one album's details
  example: {"name":"Stadium Arcadium","albumId":1,"artistId":1,"artist":{"name":"Red Hot Chili Peppers","artistId":1},"songs":[{"name":"Dani California","lyrics":"Getting born in the state of Mississippi\nPapa was a copper...


# Add an album to a specific artist based on artistId
*Request components:*
Method: POST
URL: /albums
Headers: Content-Type: application/json
Body: give the album details and the artistId to add the album to, return error if artist doesn't exist

*Response components:*
Status Code: 200
Headers: Content-Type: application/json
Content-Type: application/json
Body: json of that one album's details


**HERE**

# Edit a specified album by albumId
*Request components:*
Method:/artist/:artistId
URL: /
Headers: Content-Type: application/json
Body:

*Response components:*
Status Code:
Headers: Content-Type: application/json
Body:



# Delete a specified album by albumId
*Request components:*
Method:/artist/:artistId
URL: /
Headers: Content-Type: application/json
Body:

*Response components:*
Status Code:
Headers: Content-Type: application/json
Body:



# Get all songs of a specific artist based on artistId
*Request components:*
Method:/artist/:artistId
URL: /
Headers: Content-Type: application/json
Body:

*Response components:*
Status Code:
Headers: Content-Type: application/json
Body:



# Get all songs of a specific album based on albumId
*Request components:*
Method:/artist/:artistId
URL: /
Headers: Content-Type: application/json
Body:

*Response components:*
Status Code:
Headers: Content-Type: application/json
Body:



# Get a specific song's details based on songId
*Request components:*
Method:/artist/:artistId
URL: /
Headers: Content-Type: application/json
Body:

*Response components:*
Status Code:
Headers: Content-Type: application/json
Body:



# Add a song to a specific album based on albumId
*Request components:*
Method:/artist/:artistId
URL: /
Headers: Content-Type: application/json
Body:

*Response components:*
Status Code:
Headers: Content-Type: application/json
Body:
