fetch('/posts').then(res => res.json()).then(resBody => console.log(resBody));
