// add a new product with percent-encoded body
fetch("http://localhost:5000/products", {
  method: "POST",
  body: "name=Caribbean+Delight+Coffee&description=Made+by+Manatee+Coffee&price=11%2E99&categories=grocery",
  headers: {
    "Content-Type": "application/x-www-form-urlencoded"
  }
});



// add a new product and print the status, location of new product, and where redirected
fetch("http://localhost:5000/products", {
  method: "POST",
  body: "name=b+Delight+Coffee&description=Made+by+Manatee+Coffee&price=11%2E99&categories=grocery",
  headers: {
    "Content-Type": "application/x-www-form-urlencoded"
  }
})
  .then(response => {
    console.log(response.status)
    console.log(response.headers.get("Location"))
    console.log(response.url)
  })


//use URLSearchParams class to produce a percent-encoded string that you can send as the body of a fetch response
// it can be submitted directly in the body or assigned as a variable and the variable is in body
fetch("http://localhost:5000/products", {
  method: "POST",
  body:
    new URLSearchParams({
      name: "Caribbean Delight Coffee",
      description: "Made by Manatee Coffee",
      price: 11.99,
      categories: "grocery"
    }),
  headers: {
    "Content-Type": "application/x-www-form-urlencoded"
  }
}).then(response => {
    console.log({
      redirected: res.directed
    });
  });


//.text takes that readable stream and returns promise that resolves with result of parsing body text
fetch("https://jservice.xyz/api/games")
  .then(function (res) {
    console.log("response: ", res);
    return res.text();
  })
  .then(function (data) {
    console.log("data:", data);
  });


// Print the status code of the response
fetch("/products")
  .then(res => {
    console.log(res.status)
    console.log(res.ok)
    console.log(res.headers.get('Content-Type'))
  })
  .then(body => console.log(body))


// use an external API
const fetch = require("node-fetch");
const MOVIE_API_KEY = "ENTER THE KEY HERE";
const url = "http://www.omdapi.com?apikey=${MOVIE_API_KEY}&t=fight+club";
fetch(url)
  .then(res => res.json())
  .then(json => console.log(json.Actors))
  .catch(reason => console.log('rejected because: ', reason));
