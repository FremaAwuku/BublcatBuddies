const http = require('http');

const dogs = [
  {
    dogId: 1,
    name: "Fluffy",
    age: 2
  }
];

let nextDogId = 2;

function getNewDogId() {
  const newDogId = nextDogId;
  nextDogId++;
  return newDogId;
}

const server = http.createServer((req, res) => {
  console.log(`${req.method} ${req.url}`);

  let reqBody = "";
  req.on("data", (data) => {
    reqBody += data;
  });

  // When the request is finished processing the entire body
  req.on("end", () => {

    // route handlers

    // GET /dogs
    if (req.method === 'GET' && req.url === '/dogs') {
      res.statusCode = 200;
      res.setHeader('Content-Type', 'application/json');
      res.write(JSON.stringify(dogs));
      return res.end(); // Return the dogs array as JSON in the body of the response
    }

    // GET /dogs/:dogId
    if (req.method === 'GET' && req.url.startsWith('/dogs/')) {
      const urlParts = req.url.split('/');
      if (urlParts.length === 3) {
        const dogId = urlParts[2];
        const dog = dogs.find(dog => dog.dogId == dogId);
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.write(JSON.stringify(dog));
        return res.end();
        // Return the specified dog as JSON in the body of the response
      }
    }

    // POST /dogs
    if (req.method === 'POST' && req.url === '/dogs') {
      // Create a new dog using the `getNewDogId` function and the body of the
        // request and return the newly created dog as JSON in the body of the
      const { name, age } = req.body;
      const dog = {
        dogId: getNewDogId(),  // get the next dog id number from the server
        name,       // shorthand for name: name
        age
      };
      dogs.push(dog);  // add the new dog to the dogs array
        // response
      res.statusCode = 201;
      res.setHeader('Content-Type', 'application/json');
      res.write(JSON.stringify(dog));
      return res.end();
    }

    // PUT or PATCH /dogs/:dogId
    if ((req.method === 'PUT' || req.method === 'PATCH')  && req.url.startsWith('/dogs/')) {
      const urlParts = req.url.split('/');
      if (urlParts.length === 3) {
        const dogId = urlParts[2];
        // Edit the specified dog using the body of the request and return the
          // editted dog as JSON in the body of the response
        const { name, age } = req.body;
        const dog = dogs.find(dog => dog.dogId == dogId);
        dog.name = name || dog.name;
        dog.age = age || dog.age;

        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.write(JSON.stringify(dog));
        return res.end();
      }
    }

    // DELETE /dogs/:dogId
    if (req.method === 'DELETE' && req.url.startsWith('/dogs/')) {
      const urlParts = req.url.split('/');
      if (urlParts.length === 3) {
        const dogId = urlParts[2];
        // Remove the specified dog from the dogs array and return a message of
          // "Successfully deleted" as JSON in the body of the response
          
      }
    }

    // No matching endpoint
    res.statusCode = 404;
    res.setHeader('Content-Type', 'application/json');
    return res.end('Endpoint not found');
  });

});

const port = 5000;

server.listen(port, () => console.log('Server is listening on port', port));
